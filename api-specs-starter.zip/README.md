# Example API Specification Portal

This package contains the OpenAPI specification and a static web app frontend
for browsing API documentation across multiple environments.

## Contents

- **openapi.yaml** → Root OpenAPI specification (with all environments listed).
- **paths/** → Feature-specific endpoint definitions (`users`, `tickets`, `devices`, `health`).
- **components/** → Shared schemas, responses, parameters, and security.
- **openapi-*.yaml** → Environment-specific specifications (`dev`, `qa`, `preprod`, `prod`).
- **static/index.html** → Swagger UI portal with environment dropdown.
- **.azure-pipelines/pipeline.yml** → Azure DevOps pipeline for validation and deployment.

## How to Use

### Option 1: Open Locally
1. Unzip this package.
2. Open `static/index.html` in your browser.
3. Use the **Environment dropdown** (top bar) to switch between Dev, QA, Pre-Prod, and Prod specs.

### Option 2: Deploy to Azure Static Web Apps
1. Push this repo to your Azure DevOps project.
2. Ensure the pipeline `.azure-pipelines/pipeline.yml` is enabled.
3. Configure your Azure Static Web App deployment token (`SWA_TOKEN`) as a pipeline secret.
4. On commit to `main`, the pipeline will:
   - Validate the OpenAPI spec.
   - Generate docs.
   - Deploy to your Static Web App.
5. Share the Static Web App URL with external vendors.

## Vendor Instructions
- Visit the documentation portal URL (provided by you).
- Select the desired environment from the **dropdown menu**.
- Explore the REST API endpoints interactively via **Swagger UI**.
- Copy/paste example request/response payloads directly from the docs.

## Notes
- The API spec is modular. Add new features under `paths/` and update `openapi.yaml`.
- Common schemas and responses should go under `components/`.
- All requests and responses include **sample data** for easy testing.

---

© 2025 Example Company. All rights reserved.
