# API Specs Starter (Feature-Split, Multi-Environment)

This package contains a feature-split OpenAPI specification for your Azure Functions REST APIs, plus a single **Static Web App** frontend (Swagger UI) with an **environment dropdown** for `dev`, `qa`, `preprod`, and `prod`.

## What's Inside

```
.
├── openapi.yaml                  # Unified spec (all environments in `servers`)
├── openapi-dev.yaml              # Dev-only spec used by the dropdown
├── openapi-qa.yaml               # QA-only spec
├── openapi-preprod.yaml          # Pre-Prod-only spec
├── openapi-prod.yaml             # Prod-only spec
├── paths/                        # Feature-separated endpoint files
├── components/                   # Shared schemas/parameters/responses/security
├── static/
│   ├── index.html                # Swagger UI portal with env dropdown
│   ├── openapi.yaml              # (copy) unified spec for the portal
│   ├── openapi-dev.yaml          # (copy) used by the dropdown
│   ├── openapi-qa.yaml           # (copy)
│   ├── openapi-preprod.yaml      # (copy)
│   ├── openapi-prod.yaml         # (copy)
│   ├── paths/                    # (copy) to resolve $refs in the browser
│   └── components/               # (copy) to resolve $refs in the browser
└── .azure-pipelines/
    └── pipeline.yml              # CI: validate & deploy to Azure Static Web Apps
```

> **Why duplicates in `static/`?** Swagger UI loads `openapi*.yaml` directly in the browser. The `$ref` paths are relative to the YAML location, so we include a copy of `paths/` and `components/` beside the spec inside `static/` for the portal to resolve everything client-side.

---

## Quick Start (Local)

1. Unzip and open `static/index.html` in a browser.
2. Use the **Environment** dropdown to switch between `Default`, `Development`, `QA`, `Pre-Production`, and `Production`.
3. Click **Authorize** in Swagger UI to enter a Bearer token if your endpoints require auth.

> Tip: The **Default** option loads the unified spec (`openapi.yaml`) which already contains all server URLs in the `servers` list.

---

## Deploy to Azure Static Web Apps (Recommended)

### Option A — via Azure DevOps Pipeline (preconfigured)

1. In Azure DevOps, create pipeline variables:
   - `SWA_TOKEN` — your Static Web Apps deployment token
2. Commit/push this folder to your repo.
3. The pipeline at `.azure-pipelines/pipeline.yml` will:
   - Validate the root `openapi.yaml`
   - Deploy the **`static/`** directory to your Static Web App

> After deployment, share the SWA URL with external stakeholders. They’ll see the Swagger UI portal with the environment dropdown.

### Option B — Manual Deploy (without CI)

- Drag-and-drop the contents of the `static/` folder into your SWA created in the Azure Portal (or use the SWA CLI).
- Ensure the site root contains:
  - `index.html`
  - `openapi*.yaml`
  - `paths/` and `components/` folders

---

## How to Edit / Extend

- Add new features under `paths/feature-name.yaml` and reference them from `openapi.yaml > paths`.
- Define reusable objects under `components/` and reference via `$ref` (e.g., `../components/schemas.yaml#/User`).
- Provide `example:` payloads on schema fields and `example`/`examples` at the endpoint level for request/response bodies.

---

## Security

This template uses a `bearerAuth` scheme (JWT). In Swagger UI:
- Click **Authorize** → enter `Bearer <your-token>`
- Endpoints will send the Authorization header when using **Try it out**

---

## Support

If vendors need a single-environment file, point them to:
- `openapi-dev.yaml` / `openapi-qa.yaml` / `openapi-preprod.yaml` / `openapi-prod.yaml`

These are included at both the repo root and inside `static/` for the portal.
